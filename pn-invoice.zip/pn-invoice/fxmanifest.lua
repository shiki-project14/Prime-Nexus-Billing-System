fx_version 'cerulean'
game 'gta5'

author 'SHIKI'
description 'Prime Nexus - Advanced Invoice System'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}