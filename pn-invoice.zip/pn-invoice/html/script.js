let currentInvoices = [];

window.addEventListener('message', function(event) {
    const data = event.data;
    
    if (data.action === "openCreateInvoice") {
        document.getElementById('app').classList.remove('hidden');
        document.getElementById('create-invoice-menu').classList.remove('hidden');
        document.getElementById('dashboard-menu').classList.add('hidden');
    } 
    else if (data.action === "openDashboard") {
        currentInvoices = data.invoices; 
        
        document.getElementById('app').classList.remove('hidden');
        document.getElementById('dashboard-menu').classList.remove('hidden');
        document.getElementById('create-invoice-menu').classList.add('hidden');
        
        renderDashboard();
    }
});

function renderDashboard() {
    const container = document.getElementById('bills-list');
    container.innerHTML = ''; 

    if (currentInvoices.length === 0) {
        container.innerHTML = `<div class="empty-state"><h2><i class="fas fa-check-circle"></i></h2><p>Kamu tidak memiliki tagihan yang belum dibayar.</p></div>`;
        return;
    }

    currentInvoices.forEach(inv => {
        let icon = "fa-file-invoice";
        if(inv.jobName === "police") icon = "fa-shield-alt";
        if(inv.jobName === "mechanic") icon = "fa-wrench";
        if(inv.jobName === "ambulance") icon = "fa-ambulance";

        const billHTML = `
            <div class="bill-card">
                <div class="bill-left">
                    <div class="bill-icon"><i class="fas ${icon}"></i></div>
                    <div class="bill-info">
                        <span class="bill-type">${inv.jobName || 'Tidak Diketahui'}</span>
                        <span class="bill-sender">Dari: ${inv.senderName}</span>
                    </div>
                </div>
                
                <div class="bill-middle">
                    <div class="bill-reason-title">Deskripsi</div>
                    <div class="bill-reason">${inv.reason}</div>
                </div>

                <div class="bill-right">
                    <div class="bill-amount-box">
                        <div class="bill-amount-title">Total Tagihan</div>
                        <div class="bill-amount">$${inv.amount.toLocaleString()}</div>
                    </div>
                    <button class="btn-pay" onclick="actionBill('paid', ${inv.queueId})">Bayar Tagihan</button>
                </div>
            </div>
        `;
        container.innerHTML += billHTML;
    });
}

function sendInvoice() {
    const targetId = document.getElementById('target-id').value;
    const amount = document.getElementById('invoice-amount').value;
    const reason = document.getElementById('invoice-reason').value;

    if (!targetId || !amount || !reason) return;

    fetch(`https://${GetParentResourceName()}/submitInvoice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: targetId, amount: amount, reason: reason })
    });
    closeUI();
}

function actionBill(statusType, qId) {
    const selectedInvoice = currentInvoices.find(inv => inv.queueId === qId);
    
    if (selectedInvoice) {
        fetch(`https://${GetParentResourceName()}/processPayment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: statusType, data: selectedInvoice })
        });
        closeUI(); 
    }
}

function closeUI() {
    document.getElementById('app').classList.add('hidden');
    fetch(`https://${GetParentResourceName()}/closeUI`, { method: 'POST' });
    
    document.getElementById('target-id').value = '';
    document.getElementById('invoice-amount').value = '';
    document.getElementById('invoice-reason').value = '';
}