local framework = "standalone"
local ESX, QBCore, Ox = nil, nil, nil

if GetResourceState('ox_core') == 'started' then
    framework = "oxcore"
    Ox = require '@ox_core.lib.init'
elseif GetResourceState('qbx_core') == 'started' then
    framework = "qbxcore"
elseif GetResourceState('qb-core') == 'started' then
    framework = "qbcore"
    QBCore = exports['qb-core']:GetCoreObject()
elseif GetResourceState('es_extended') == 'started' then
    framework = "esx"
    ESX = exports['es_extended']:getSharedObject()
end

print("[Prime Nexus] Terhubung ke Framework: " .. string.upper(framework))

RegisterNetEvent("primenexus:server:sendInvoiceToPlayer")
AddEventHandler("primenexus:server:sendInvoiceToPlayer", function(targetId, amount, reason)
    local src = source
    local target = tonumber(targetId)
    local billAmount = tonumber(amount)
    local jobName = "unknown"

    if framework == "esx" then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then jobName = xPlayer.job.name end
    elseif framework == "qbcore" then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then jobName = Player.PlayerData.job.name end
    elseif framework == "qbxcore" then
        local Player = exports.qbx_core:GetPlayer(src)
        if Player then jobName = Player.PlayerData.job.name end
    elseif framework == "oxcore" then
        local player = Ox.GetPlayer(src)
        if player then 
            local groups = player.getGroups()
            for group, grade in pairs(groups) do
                jobName = group
                break 
            end
        end
    end

    if GetPlayerEndpoint(target) then
        local invoiceData = {
            senderId = src,
            targetId = target,
            amount = billAmount,
            reason = reason,
            senderName = "Petugas [" .. src .. "]",
            jobName = jobName
        }
        
        TriggerClientEvent("primenexus:client:receiveInvoice", target, invoiceData)
        TriggerClientEvent('chat:addMessage', src, {args = {"[Prime Nexus]", "Invoice Berhasil dikirim !"}})
    else
        TriggerClientEvent('chat:addMessage', src, {args = {"[Prime Nexus]", "Pemain tidak ditemukan."}})
    end
end)

RegisterNetEvent("primenexus:server:handlePaymentStatus")
AddEventHandler("primenexus:server:handlePaymentStatus", function(status, invoiceData)
    local src = source
    local senderId = invoiceData.senderId
    local amount = tonumber(invoiceData.amount)
    local jobName = invoiceData.jobName

    if status == "paid" then
        local societyCut = math.floor(amount * 0.70)
        local playerCut = amount - societyCut
        local paymentSuccess = false
        local payerName = GetPlayerName(src)

        if framework == "esx" then
            local xTarget = ESX.GetPlayerFromId(src)
            local xSender = ESX.GetPlayerFromId(senderId)
            
            if xTarget then
                payerName = xTarget.getName()
                if xTarget.getAccount('bank').money >= amount then
                    xTarget.removeAccountMoney('bank', amount)
                    paymentSuccess = true
                    
                    if xSender then
                        xSender.addAccountMoney('bank', playerCut)
                    else
                        societyCut = amount
                    end
                    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_' .. jobName, function(account)
                        if account then account.addMoney(societyCut) end
                    end)
                end
            end

        elseif framework == "qbcore" then
            local Target = QBCore.Functions.GetPlayer(src)
            local Sender = QBCore.Functions.GetPlayer(senderId)

            if Target then
                payerName = Target.PlayerData.charinfo.firstname .. " " .. Target.PlayerData.charinfo.lastname -- Ambil nama in-game QBCore
                if Target.Functions.RemoveMoney('bank', amount, "paid-invoice") then
                    paymentSuccess = true
                    if Sender then
                        Sender.Functions.AddMoney('bank', playerCut, "invoice-commission")
                    else
                        societyCut = amount
                    end
                    exports['qb-management']:AddMoney(jobName, societyCut)
                end
            end

        elseif framework == "qbxcore" then
            local Target = exports.qbx_core:GetPlayer(src)
            local Sender = exports.qbx_core:GetPlayer(senderId)

            if Target then
                payerName = Target.PlayerData.charinfo.firstname .. " " .. Target.PlayerData.charinfo.lastname
                if Target.Functions.RemoveMoney('bank', amount, "paid-invoice") then
                    paymentSuccess = true
                    if Sender then
                        Sender.Functions.AddMoney('bank', playerCut, "invoice-commission")
                    else
                        societyCut = amount
                    end
                    exports['Renewed-Banking']:addAccountMoney(jobName, societyCut)
                end
            end

        elseif framework == "oxcore" then
            local Target = Ox.GetPlayer(src)
            local Sender = Ox.GetPlayer(senderId)

            if Target then
                payerName = Target.get('firstName') .. " " .. Target.get('lastName')
                if Target.getAccount('bank').balance >= amount then
                    Target.removeAccountBalance('bank', amount)
                    paymentSuccess = true
                    
                    if Sender then
                        Sender.addAccountBalance('bank', playerCut)
                    else
                        societyCut = amount
                    end
                end
            end
        end

        if paymentSuccess then
            TriggerClientEvent('chat:addMessage', src, {args = {"[Prime Nexus]", "Berhasil membayar tagihan sebesar $" .. amount .. " ke " .. string.upper(jobName)}})

            if GetPlayerEndpoint(senderId) then 
                TriggerClientEvent('chat:addMessage', senderId, {args = {"[Prime Nexus]", "Player " .. payerName .. " berhasil membayar tagihan komisi 30% sudah masuk ke bank"}})
            end
        else
            TriggerClientEvent('chat:addMessage', src, {args = {"[Prime Nexus]", "Saldo Bank tidak mencukupi!"}})
            if GetPlayerEndpoint(senderId) then 
                TriggerClientEvent('chat:addMessage', senderId, {args = {"[Prime Nexus]", "Target gagal membayar (Saldo Bank kurang)."}})
            end
        end
    end
end)