# 📄 Prime Nexus - Advanced Billing System

Script invoice/tagihan FiveM interaktif dengan UI modern, full Bahasa Indonesia, dan fitur keamanan ekstra untuk roleplay yang lebih realistis. 

Dibuat khusus untuk memastikan para pekerja di kota (Mekanik, Polisi, EMS, dll) mendapatkan haknya tanpa khawatir pelanggan kabur atau menolak tagihan secara sepihak.

## ✨ Fitur Utama
* **🚀 UI/UX Modern & Elegan:** Tampilan dashboard yang memanjakan mata.
* **👤 Notifikasi Nama IC:** Pesan notifikasi pembayaran menggunakan nama asli karakter di dalam game, bukan sekadar ID.
* **💼 Sistem Komisi:** Pembagian uang otomatis (Default: 70% masuk ke brankas/society job, 30% masuk ke kantong pembuat tagihan).
* **🛠️ Multi-Framework Auto-Detect:** Script otomatis mendeteksi framework yang kamu pakai (ESX, QBCore, Qbox, atau Ox Core).

## 📥 Cara Pemasangan (Installation)
1. Unduh (Download) file script ini dari Discord kami.
2. Ekstrak folder script dan letakkan di dalam folder `resources` server kamu (misal: di dalam folder `[standalone]` atau `[local]`).
3. Pastikan nama foldernya adalah `pn-invoice` (atau sesuaikan dengan keinginanmu, namun hindari penggunaan spasi).
4. Buka file `server.cfg` milikmu.
5. Tambahkan baris kode berikut di bagian paling bawah atau di tempat kamu biasa menaruh script baru:
   ```text
   ensure pn-invoice