local framework = "standalone"
local PlayerJob = "unknown"
local ESX, QBCore = nil, nil

-- ==========================================
-- KONFIGURASI JOB
-- ==========================================
local AllowedJobs = {
    ["police"] = true,     -- Polisi
    ["mechanic"] = true,   -- Mekanik
    ["ambulance"] = true,  -- EMS / Ambulance
    ["pedagang"] = true,   -- Pedagang
    ["club"] = true        -- Club / Nightclub
}

CreateThread(function()
    Wait(1000)

    if GetResourceState('ox_core') == 'started' then
        framework = "oxcore"
        local groups = LocalPlayer.state.groups
        if groups then
            for k, v in pairs(groups) do
                PlayerJob = k
                break
            end
        end

    elseif GetResourceState('qbx_core') == 'started' then
        framework = "qbxcore"
        local PlayerData = exports.qbx_core:GetPlayerData()
        if PlayerData and PlayerData.job then
            PlayerJob = PlayerData.job.name
        end

    elseif GetResourceState('qb-core') == 'started' then
        framework = "qbcore"
        QBCore = exports['qb-core']:GetCoreObject()
        local PlayerData = QBCore.Functions.GetPlayerData()
        if PlayerData and PlayerData.job then
            PlayerJob = PlayerData.job.name
        end

    elseif GetResourceState('es_extended') == 'started' then
        framework = "esx"
        ESX = exports['es_extended']:getSharedObject()
        local PlayerData = ESX.GetPlayerData()
        if PlayerData and PlayerData.job then
            PlayerJob = PlayerData.job.name
        end
    end

    print("[Prime Nexus] Client terhubung ke Framework: " .. string.upper(framework))
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    if framework == "esx" then PlayerJob = job.name end
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate')
AddEventHandler('QBCore:Client:OnJobUpdate', function(JobInfo)
    if framework == "qbcore" or framework == "qbxcore" then PlayerJob = JobInfo.name end
end)

RegisterNetEvent('qbx_core:client:OnJobUpdate')
AddEventHandler('qbx_core:client:OnJobUpdate', function(JobInfo)
    if framework == "qbxcore" then PlayerJob = JobInfo.name end
end)

AddStateBagChangeHandler('groups', nil, function(bagName, key, value, _reserved, replicated)
    if framework == "oxcore" then
        local ply = GetPlayerFromStateBagName(bagName)
        if ply == PlayerId() then
            if value then
                for k, v in pairs(value) do
                    PlayerJob = k
                    break
                end
            else
                PlayerJob = "unknown"
            end
        end
    end
end)

local function hasInvoiceAccess()
    return AllowedJobs[PlayerJob] == true
end

RegisterCommand("createinvoice", function()
    if hasInvoiceAccess() then
        SetNuiFocus(true, true)
        SendNUIMessage({ action = "openCreateInvoice" })
    else
        if framework == "esx" then
            ESX.ShowNotification("Akses Ditolak: Anda bukan petugas berwenang.")
        elseif framework == "qbcore" or framework == "qbxcore" then
            TriggerEvent('QBCore:Notify', "Akses Ditolak: Anda bukan petugas berwenang.", "error")
        elseif framework == "oxcore" then
            if GetResourceState('ox_lib') == 'started' then
                exports.ox_lib:notify({title = 'Akses Ditolak', description = 'Anda bukan petugas berwenang.', type = 'error'})
            else
                TriggerEvent('chat:addMessage', {args = {"[Prime Nexus]", "Akses Ditolak: Anda bukan petugas berwenang."}})
            end
        else
            TriggerEvent('chat:addMessage', {args = {"[Prime Nexus]", "Akses Ditolak: Anda bukan petugas berwenang."}})
        end
    end
end)

local PendingInvoices = {} 

RegisterNetEvent("primenexus:client:receiveInvoice")
AddEventHandler("primenexus:client:receiveInvoice", function(invoiceData)
    invoiceData.queueId = math.random(100000, 999999)
    table.insert(PendingInvoices, invoiceData)
    
    local msg = "Tagihan masuk dari " .. string.upper(invoiceData.jobName) .. " !"
    
    if framework == "esx" then ESX.ShowNotification(msg)
    elseif framework == "qbcore" or framework == "qbxcore" then TriggerEvent('QBCore:Notify', msg, "primary", 7000)
    else TriggerEvent('chat:addMessage', {args = {"[Prime Nexus]", msg}}) end
end)

RegisterCommand("cektagihan", function()
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openDashboard",
        invoices = PendingInvoices
    })
end)

RegisterCommand("cleartagihan", function()
    PendingInvoices = {}
    TriggerEvent('chat:addMessage', {args = {"[Prime Nexus]", "Semua antrean tagihan telah dibersihkan."}})
end)

RegisterNUICallback("closeUI", function(data, cb)
    SetNuiFocus(false, false)
    if cb then cb('ok') end
end)

RegisterNUICallback("submitInvoice", function(data, cb)
    SetNuiFocus(false, false)
    TriggerServerEvent("primenexus:server:sendInvoiceToPlayer", data.target, data.amount, data.reason)
    if cb then cb('ok') end
end)

RegisterNUICallback("processPayment", function(data, cb)
    SetNuiFocus(false, false)
    TriggerServerEvent("primenexus:server:handlePaymentStatus", data.status, data.data)
    
    local processedInvoice = data.data
    if processedInvoice and processedInvoice.queueId then
        for i, inv in ipairs(PendingInvoices) do
            if inv.queueId == processedInvoice.queueId then
                table.remove(PendingInvoices, i)
                break
            end
        end
    end
    
    if cb then cb('ok') end
end)